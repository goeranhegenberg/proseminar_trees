# Security Policy

## Supported Versions

Starting with Celero v2.5.0, we will be activly scanning and doing analysis to ensure that this library remains free of security vulnerabilities.

| Version | Supported          |
| ------- | ------------------ |
| 2.5.x   | :white_check_mark: |

## Reporting a Vulnerability

If you find or suspect a vulnerability within this library, please report it on the Issues page.  
